# Copyright (c) 2013 Yubico AB
# All rights reserved.
#
#   Redistribution and use in source and binary forms, with or
#   without modification, are permitted provided that the following
#   conditions are met:
#
#    1. Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#    2. Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from fido_host.u2f import CTAP1, ApduError, APDU, U2fClient, ClientError
from fido_host.utils import sha256, websafe_decode
from threading import Event
import unittest
import mock


class TestCTAP1(unittest.TestCase):

    def test_send_apdu_ok(self):
        ctap = CTAP1(mock.MagicMock())
        ctap.device.call.return_value = b'response\x90\x00'

        self.assertEqual(b'response', ctap.send_apdu(1, 2, 3, 4, b'foobar'))
        ctap.device.call.assert_called_with(0x03, b'\1\2\3\4\0\0\6foobar\0\0')

    def test_send_apdu_err(self):
        ctap = CTAP1(mock.MagicMock())
        ctap.device.call.return_value = b'err\x6a\x80'

        try:
            ctap.send_apdu(1, 2, 3, 4, b'foobar')
            self.fail('send_apdu did not raise error')
        except ApduError as e:
            self.assertEqual(e.code, 0x6a80)
            self.assertEqual(e.data, b'err')
        ctap.device.call.assert_called_with(0x03, b'\1\2\3\4\0\0\6foobar\0\0')

    def test_get_version(self):
        ctap = CTAP1(mock.MagicMock())
        ctap.device.call.return_value = b'U2F_V2\x90\x00'

        self.assertEqual('U2F_V2', ctap.get_version())
        ctap.device.call.assert_called_with(0x03, b'\0\3\0\0\0\0\0\0\0')

    def test_register(self):
        ctap = CTAP1(mock.MagicMock())
        ctap.device.call.return_value = b'response\x90\x00'

        ctap.register(b'\1'*32, b'\2'*32)
        ctap.device.call.assert_called_with(0x03, b'\0\1\0\0\0\0\x40' +
                                            b'\1'*32 + b'\2'*32 + b'\0\0')

    def test_authenticate(self):
        ctap = CTAP1(mock.MagicMock())
        ctap.device.call.return_value = b'response\x90\x00'

        ctap.authenticate(b'\1'*32, b'\2'*32, b'\3'*64)
        ctap.device.call.assert_called_with(0x03, b'\0\2\3\0\0\0\x81' +
                                            b'\1'*32 + b'\2'*32 + b'\x40' +
                                            b'\3'*64 + b'\0\0')

        ctap.authenticate(b'\1'*32, b'\2'*32, b'\3'*8)
        ctap.device.call.assert_called_with(0x03, b'\0\2\3\0\0\0\x49' +
                                            b'\1'*32 + b'\2'*32 + b'\x08' +
                                            b'\3'*8 + b'\0\0')

        ctap.authenticate(b'\1'*32, b'\2'*32, b'\3'*8, True)
        ctap.device.call.assert_called_with(0x03, b'\0\2\7\0\0\0\x49' +
                                            b'\1'*32 + b'\2'*32 + b'\x08' +
                                            b'\3'*8 + b'\0\0')


APP_ID = 'https://foo.example.com'


class TestU2fClient(unittest.TestCase):

    def test_register_unsupported_version(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_XXX'

        try:
            client.register(
                APP_ID, [{'version': 'U2F_V2', 'challenge': 'foobar'}], [],
                timeout=1)
            self.fail('register did not raise error')
        except ClientError as e:
            self.assertEqual(e.code, ClientError.ERR.DEVICE_INELIGIBLE)

        client.ctap.get_version.assert_called_with()

    def test_register_existing_key(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_V2'
        client.ctap.authenticate.side_effect = ApduError(APDU.USE_NOT_SATISFIED)

        try:
            client.register(
                APP_ID, [{'version': 'U2F_V2', 'challenge': 'foobar'}],
                [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}],
                timeout=1)
            self.fail('register did not raise error')
        except ClientError as e:
            self.assertEqual(e.code, ClientError.ERR.DEVICE_INELIGIBLE)

        client.ctap.get_version.assert_called_with()
        client.ctap.authenticate.assert_called_once()
        # Check keyHandle
        self.assertEqual(client.ctap.authenticate.call_args[0][2], b'key')
        # Ensure check-only was set
        self.assertTrue(client.ctap.authenticate.call_args[0][3])

    def test_register(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_V2'
        client.ctap.authenticate.side_effect = ApduError(APDU.WRONG_DATA)
        client.ctap.register.return_value = b'regdata'

        resp = client.register(
            APP_ID, [{'version': 'U2F_V2', 'challenge': 'foobar'}],
            [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}]
        )

        client.ctap.get_version.assert_called_with()
        client.ctap.authenticate.assert_called_once()
        client.ctap.register.assert_called_once()

        client_param, app_param = client.ctap.register.call_args[0]
        self.assertEqual(sha256(websafe_decode(resp['clientData'])),
                         client_param)
        self.assertEqual(websafe_decode(resp['registrationData']), b'regdata')
        self.assertEqual(sha256(APP_ID.encode()), app_param)

    def test_register_await_timeout(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_V2'
        client.ctap.authenticate.side_effect = ApduError(APDU.WRONG_DATA)
        client.ctap.register.side_effect = ApduError(APDU.USE_NOT_SATISFIED)

        client.poll_delay = 0.01
        try:
            client.register(
                APP_ID, [{'version': 'U2F_V2', 'challenge': 'foobar'}],
                [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}],
                timeout=0.1
            )
        except ClientError as e:
            self.assertEqual(e.code, ClientError.ERR.TIMEOUT)

    def test_register_await_touch(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_V2'
        client.ctap.authenticate.side_effect = ApduError(APDU.WRONG_DATA)
        client.ctap.register.side_effect = [
            ApduError(APDU.USE_NOT_SATISFIED),
            ApduError(APDU.USE_NOT_SATISFIED),
            ApduError(APDU.USE_NOT_SATISFIED),
            ApduError(APDU.USE_NOT_SATISFIED),
            b'regdata'
        ]

        event = Event()
        event.wait = mock.MagicMock()
        resp = client.register(
            APP_ID, [{'version': 'U2F_V2', 'challenge': 'foobar'}],
            [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}],
            timeout=event
        )

        event.wait.assert_called()

        client.ctap.get_version.assert_called_with()
        client.ctap.authenticate.assert_called_once()
        client.ctap.register.assert_called()

        client_param, app_param = client.ctap.register.call_args[0]
        self.assertEqual(sha256(websafe_decode(resp['clientData'])),
                         client_param)
        self.assertEqual(websafe_decode(resp['registrationData']), b'regdata')
        self.assertEqual(sha256(APP_ID.encode()), app_param)

    def test_sign_unsupported_version(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_XXX'

        try:
            client.sign(
                APP_ID, 'challenge',
                [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}]
            )
            self.fail('register did not raise error')
        except ClientError as e:
            self.assertEqual(e.code, ClientError.ERR.DEVICE_INELIGIBLE)

        client.ctap.get_version.assert_called_with()

    def test_sign_missing_key(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_V2'
        client.ctap.authenticate.side_effect = ApduError(APDU.WRONG_DATA)

        try:
            client.sign(
                APP_ID, 'challenge',
                [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}],
            )
            self.fail('register did not raise error')
        except ClientError as e:
            self.assertEqual(e.code, ClientError.ERR.DEVICE_INELIGIBLE)

        client.ctap.get_version.assert_called_with()
        client.ctap.authenticate.assert_called_once()
        _, app_param, key_handle = client.ctap.authenticate.call_args[0]
        self.assertEqual(app_param, sha256(APP_ID.encode()))
        self.assertEqual(key_handle, b'key')

    def test_sign(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_V2'
        client.ctap.authenticate.return_value = b'signatureData'

        resp = client.sign(
            APP_ID, 'challenge',
            [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}],
        )

        client.ctap.get_version.assert_called_with()
        client.ctap.authenticate.assert_called_once()
        client_param, app_param, key_handle = \
            client.ctap.authenticate.call_args[0]

        self.assertEqual(client_param,
                         sha256(websafe_decode(resp['clientData'])))
        self.assertEqual(app_param, sha256(APP_ID.encode()))
        self.assertEqual(key_handle, b'key')

    def test_sign_await_touch(self):
        client = U2fClient(None, APP_ID)
        client.ctap = mock.MagicMock()
        client.ctap.get_version.return_value = 'U2F_V2'
        client.ctap.authenticate.side_effect = [
            ApduError(APDU.USE_NOT_SATISFIED),
            ApduError(APDU.USE_NOT_SATISFIED),
            ApduError(APDU.USE_NOT_SATISFIED),
            ApduError(APDU.USE_NOT_SATISFIED),
            b'signatureData'
        ]

        event = Event()
        event.wait = mock.MagicMock()

        resp = client.sign(
            APP_ID, 'challenge',
            [{'version': 'U2F_V2', 'keyHandle': 'a2V5'}],
            timeout=event
        )

        event.wait.assert_called()

        client.ctap.get_version.assert_called_with()
        client.ctap.authenticate.assert_called()
        client_param, app_param, key_handle = \
            client.ctap.authenticate.call_args[0]

        self.assertEqual(client_param,
                         sha256(websafe_decode(resp['clientData'])))
        self.assertEqual(app_param, sha256(APP_ID.encode()))
        self.assertEqual(key_handle, b'key')
