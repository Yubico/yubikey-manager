# Copyright (c) 2013 Yubico AB
# All rights reserved.
#
#   Redistribution and use in source and binary forms, with or
#   without modification, are permitted provided that the following
#   conditions are met:
#
#    1. Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#    2. Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from fido_host.fido2 import CTAP2, PinProtocolV1, Fido2Client
from fido_host import cbor
from binascii import a2b_hex
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import ec

import unittest
import mock

_INFO = a2b_hex('a60182665532465f5632684649444f5f325f3002826375766d6b686d61632d7365637265740350f8a011f38c0a4d15800617111f9edc7d04a462726bf5627570f564706c6174f469636c69656e7450696ef4051904b0068101')  # noqa


class TestCTAP2(unittest.TestCase):
    def test_send_cbor_ok(self):
        ctap = CTAP2(mock.MagicMock())
        ctap.device.call.return_value = b'\0' + cbor.dumps({1: b'response'})

        self.assertEqual({1: b'response'}, ctap.send_cbor(2, b'foobar'))
        ctap.device.call.assert_called_with(0x10, b'\2' + cbor.dumps(b'foobar'))

    def test_get_info(self):
        ctap = CTAP2(mock.MagicMock())
        ctap.device.call.return_value = b'\0' + _INFO

        info = ctap.get_info()
        ctap.device.call.assert_called_with(0x10, b'\4')
        self.assertEqual(info.versions, ['U2F_V2', 'FIDO_2_0'])
        self.assertEqual(info.extensions, ['uvm', 'hmac-secret'])
        self.assertEqual(info.aaguid,
                         a2b_hex('F8A011F38C0A4D15800617111F9EDC7D'))
        self.assertEqual(info.options, {
            'rk': True,
            'up': True,
            'plat': False,
            'clientPin': False
        })
        self.assertEqual(info.max_msg_size, 1200)
        self.assertEqual(info.pin_protocols, [1])


EC_PRIV = 0x7452e599fee739d8a653f6a507343d12d382249108a651402520b72f24fe7684
EC_PUB_X = a2b_hex('44D78D7989B97E62EA993496C9EF6E8FD58B8B00715F9A89153DDD9C4657E47F')  # noqa
EC_PUB_Y = a2b_hex('EC802EE7D22BD4E100F12E48537EB4E7E96ED3A47A0A3BD5F5EEAB65001664F9')  # noqa
DEV_PUB_X = a2b_hex('0501D5BC78DA9252560A26CB08FCC60CBE0B6D3B8E1D1FCEE514FAC0AF675168')  # noqa
DEV_PUB_Y = a2b_hex('D551B3ED46F665731F95B4532939C25D91DB7EB844BD96D4ABD4083785F8DF47')  # noqa
SHARED = a2b_hex('c42a039d548100dfba521e487debcbbb8b66bb7496f8b1862a7a395ed83e1a1c')  # noqa
TOKEN_ENC = a2b_hex('7A9F98E31B77BE90F9C64D12E9635040')
TOKEN = a2b_hex('aff12c6dcfbf9df52f7a09211e8865cd')
PIN_HASH_ENC = a2b_hex('afe8327ce416da8ee3d057589c2ce1a9')


class TestPinProtocolV1(unittest.TestCase):

    @mock.patch('cryptography.hazmat.primitives.asymmetric.ec.generate_private_key')  # noqa
    def test_establish_shared_secret(self, patched_generate):
        prot = PinProtocolV1(mock.MagicMock())

        patched_generate.return_value = ec.derive_private_key(
            EC_PRIV,
            ec.SECP256R1(),
            default_backend()
        )

        prot.ctap.client_pin.return_value = {
            1: {
                1: 2,
                3: -25,
                -1: 1,
                -2: DEV_PUB_X,
                -3: DEV_PUB_Y
            }
        }

        key_agreement, shared = prot._init_shared_secret()

        self.assertEqual(shared, SHARED)
        self.assertEqual(key_agreement[-2], EC_PUB_X)
        self.assertEqual(key_agreement[-3], EC_PUB_Y)

    def test_get_pin_token(self):
        prot = PinProtocolV1(mock.MagicMock())
        prot._init_shared_secret = mock.Mock(return_value=({}, SHARED))
        prot.ctap.client_pin.return_value = {
            2: TOKEN_ENC
        }

        self.assertEqual(prot.get_pin_token('1234'), TOKEN)
        prot.ctap.client_pin.assert_called_once()
        self.assertEqual(prot.ctap.client_pin.call_args[1]['pin_hash_enc'],
                         PIN_HASH_ENC)

    def test_set_pin(self):
        prot = PinProtocolV1(mock.MagicMock())
        prot._init_shared_secret = mock.Mock(return_value=({}, SHARED))

        prot.set_pin('1234')
        prot.ctap.client_pin.assert_called_with(
            1,
            3,
            key_agreement={},
            new_pin_enc=a2b_hex('0222fc42c6dd76a274a7057858b9b29d98e8a722ec2dc6668476168c5320473cec9907b4cd76ce7943c96ba5683943211d84471e64d9c51e54763488cd66526a'),  # noqa
            pin_auth=a2b_hex('7b40c084ccc5794194189ab57836475f')
        )

    def test_change_pin(self):
        prot = PinProtocolV1(mock.MagicMock())
        prot._init_shared_secret = mock.Mock(return_value=({}, SHARED))

        prot.change_pin('1234', '4321')
        prot.ctap.client_pin.assert_called_with(
            1,
            4,
            key_agreement={},
            new_pin_enc=a2b_hex('4280e14aac4fcbf02dd079985f0c0ffc9ea7d5f9c173fd1a4c843826f7590cb3c2d080c6923e2fe6d7a52c31ea1309d3fcca3dedae8a2ef14b6330cafc79339e'),  # noqa
            pin_auth=a2b_hex('fb97e92f3724d7c85e001d7f93e6490a'),
            pin_hash_enc=a2b_hex('afe8327ce416da8ee3d057589c2ce1a9')
        )

    def test_short_pin(self):
        prot = PinProtocolV1(mock.MagicMock())
        with self.assertRaises(ValueError):
            prot.set_pin('123')

    def test_long_pin(self):
        prot = PinProtocolV1(mock.MagicMock())
        with self.assertRaises(ValueError):
            prot.set_pin('1'*256)
