# coding=utf-8

# Copyright (c) 2013 Yubico AB
# All rights reserved.
#
#   Redistribution and use in source and binary forms, with or
#   without modification, are permitted provided that the following
#   conditions are met:
#
#    1. Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#    2. Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.


import unittest
from binascii import a2b_hex

from fido_host.utils import (
    ClientData,
    sha256,
    websafe_encode,
    websafe_decode
)


class TestSha256(unittest.TestCase):

    def test_sha256_vectors(self):
        self.assertEqual(sha256(b'abc'), a2b_hex(b'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'))  #noqa
        self.assertEqual(sha256(b'abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq'), a2b_hex(b'248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1'))  #noqa


class TestWebSafe(unittest.TestCase):
    # Base64 vectors adapted from https://tools.ietf.org/html/rfc4648#section-10

    def test_websafe_decode(self):
        self.assertEqual(websafe_decode(b''), b'')
        self.assertEqual(websafe_decode(b'Zg'), b'f')
        self.assertEqual(websafe_decode(b'Zm8'), b'fo')
        self.assertEqual(websafe_decode(b'Zm9v'), b'foo')
        self.assertEqual(websafe_decode(b'Zm9vYg'), b'foob')
        self.assertEqual(websafe_decode(b'Zm9vYmE'), b'fooba')
        self.assertEqual(websafe_decode(b'Zm9vYmFy'), b'foobar')

    def test_websafe_decode_unicode(self):
        self.assertEqual(websafe_decode(u''), b'')
        self.assertEqual(websafe_decode(u'Zm9vYmFy'), b'foobar')

    def test_websafe_encode(self):
        self.assertEqual(websafe_encode(b''), u'')
        self.assertEqual(websafe_encode(b'f'), u'Zg')
        self.assertEqual(websafe_encode(b'fo'), u'Zm8')
        self.assertEqual(websafe_encode(b'foo'), u'Zm9v')
        self.assertEqual(websafe_encode(b'foob'), u'Zm9vYg')
        self.assertEqual(websafe_encode(b'fooba'), u'Zm9vYmE')
        self.assertEqual(websafe_encode(b'foobar'), u'Zm9vYmFy')

    def test_websafe_encode_unicode(self):
        self.assertEqual(websafe_encode(u''), u'')
        self.assertEqual(websafe_encode(u'foobar'), u'Zm9vYmFy')


class TestClientData(unittest.TestCase):

    def test_client_data(self):
        client_data = ClientData(b'{"typ":"navigator.id.finishEnrollment","challenge":"vqrS6WXDe1JUs5_c3i4-LkKIHRr-3XVb3azuA5TifHo","cid_pubkey":{"kty":"EC","crv":"P-256","x":"HzQwlfXX7Q4S5MtCCnZUNBw3RMzPO9tOyWjBqRl4tJ8","y":"XVguGFLIZx1fXg3wNqfdbn75hi4-_7-BxhMljw42Ht4"},"origin":"http://example.com"}')  # noqa

        self.assertEqual(client_data.hash, a2b_hex('4142d21c00d94ffb9d504ada8f99b721f4b191ae4e37ca0140f696b6983cfacb'))  # noqa

        self.assertEqual(client_data.bytes,
                         ClientData.from_b64(client_data.b64).bytes)
