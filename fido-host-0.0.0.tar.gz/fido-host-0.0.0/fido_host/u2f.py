# Copyright (c) 2013 Yubico AB
# All rights reserved.
#
#   Redistribution and use in source and binary forms, with or
#   without modification, are permitted provided that the following
#   conditions are met:
#
#    1. Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#    2. Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from __future__ import absolute_import

from .hid import CTAPHID
from .rpid import verify_app_id
from .utils import websafe_encode, websafe_decode, sha256, ClientData

from enum import IntEnum, unique
from threading import Event, Timer
import struct


@unique
class APDU(IntEnum):
    OK = 0x9000
    USE_NOT_SATISFIED = 0x6985
    WRONG_DATA = 0x6a80


class ApduError(Exception):

    def __init__(self, code, data=b''):
        self.code = code
        self.data = data

    def __str__(self):
        return 'APDU error: 0x{:04X} {:d} bytes of data'.format(
            self.code, len(self.data))


class ClientError(Exception):

    @unique
    class ERR(IntEnum):
        OTHER_ERROR = 1
        BAD_REQUEST = 2
        CONFIGURATION_UNSUPPORTED = 3
        DEVICE_INELIGIBLE = 4
        TIMEOUT = 5

        def __call__(self):
            return ClientError(self)

    def __init__(self, code):
        self.code = ClientError.ERR(code)

    def __str__(self):
        return 'U2F Client error: {0} - {0.name}'.format(self.code)


class CTAP1(object):

    @unique
    class INS(IntEnum):
        REGISTER = 0x01
        AUTHENTICATE = 0x02
        VERSION = 0x03

    def __init__(self, device):
        self.device = device

    def send_apdu(self, cla=0, ins=0, p1=0, p2=0, data=b''):
        size = len(data)
        size_h = size >> 16 & 0xff
        size_l = size & 0xffff
        apdu = struct.pack('>BBBBBH', cla, ins, p1, p2, size_h, size_l) \
            + data + b'\0\0'

        response = self.device.call(CTAPHID.MSG, apdu)
        status = struct.unpack('>H', response[-2:])[0]
        data = response[:-2]
        if status != APDU.OK:
            raise ApduError(status, data)
        return data

    def get_version(self):
        return self.send_apdu(ins=CTAP1.INS.VERSION).decode()

    def register(self, client_param, app_param):
        data = client_param + app_param
        return self.send_apdu(ins=CTAP1.INS.REGISTER, data=data)

    def authenticate(self, client_param, app_param, key_handle,
                     check_only=False):
        data = client_param + app_param \
            + struct.pack('>B', len(key_handle)) + key_handle
        p1 = 0x07 if check_only else 0x03
        return self.send_apdu(ins=CTAP1.INS.AUTHENTICATE, p1=p1, data=data)


_event_class = type(Event())  # On Python 2 threading.Event is a function.


class U2fClient(object):
    def __init__(self, device, origin, verify=verify_app_id):
        self.poll_delay = 0.25
        self.ctap = CTAP1(device)
        self.origin = origin
        self._verify = verify_app_id

    def _verify_app_id(self, app_id):
        try:
            if self._verify(app_id, self.origin):
                return
        except Exception:
            pass  # Fall through to ClientError
        raise ClientError.ERR.BAD_REQUEST()

    def _call_polling(self, timeout, func, *args, **kwargs):
        if isinstance(timeout, _event_class):
            event = timeout
            timer = None

            def on_ret(): pass
        else:
            event = Event()
            timer = Timer(timeout, event.set)
            timer.start()

            def on_ret():
                timer.cancel()
                timer.join()
        try:
            while not event.is_set():
                try:
                    return func(*args, **kwargs)
                except ApduError as e:
                    if e.code == APDU.USE_NOT_SATISFIED:
                        event.wait(self.poll_delay)
                    else:
                        raise
            raise ClientError.ERR.TIMEOUT()
        finally:
            on_ret()

    def register(self, app_id, register_requests, registered_keys, timeout=30):
        self._verify_app_id(app_id)

        version = self.ctap.get_version()
        dummy_param = b'\0'*32
        for key in registered_keys:
            if key['version'] != version:
                continue
            key_app_id = key.get('appId', app_id)
            app_param = sha256(key_app_id.encode())
            self._verify_app_id(key_app_id)
            key_handle = websafe_decode(key['keyHandle'])
            try:
                self.ctap.authenticate(dummy_param, app_param, key_handle, True)
                raise ClientError.ERR.DEVICE_INELIGIBLE()  # Bad response
            except ApduError as e:
                if e.code == APDU.USE_NOT_SATISFIED:
                    raise ClientError.ERR.DEVICE_INELIGIBLE()

        for request in register_requests:
            if request['version'] == version:
                challenge = request['challenge']
                break
        else:
            raise ClientError.ERR.DEVICE_INELIGIBLE()

        client_data = ClientData.build(
            typ='navigator.id.finishEnrollment',
            challenge=challenge,
            origin=self.origin
        )
        app_param = sha256(app_id.encode())

        response = self._call_polling(
            timeout, self.ctap.register, client_data.hash, app_param)
        return {
            'registrationData': websafe_encode(response),
            'clientData': client_data.b64
        }

    def sign(self, app_id, challenge, registered_keys, timeout=30):
        client_data = ClientData.build(
            typ='navigator.id.getAssertion',
            challenge=challenge,
            origin=self.origin
        )

        version = self.ctap.get_version()
        for key in registered_keys:
            if key['version'] == version:
                key_app_id = key.get('appId', app_id)
                self._verify_app_id(key_app_id)
                key_handle = websafe_decode(key['keyHandle'])
                app_param = sha256(key_app_id.encode())
                try:
                    response = self._call_polling(
                        timeout, self.ctap.authenticate, client_data.hash,
                        app_param, key_handle)
                    break
                except ApduError:
                    pass  # Ignore and try next key
        else:
            raise ClientError.ERR.DEVICE_INELIGIBLE()

        return {
            'clientData': client_data.b64,
            'signatureData': websafe_encode(response),
            'keyHandle': key['keyHandle']
        }
