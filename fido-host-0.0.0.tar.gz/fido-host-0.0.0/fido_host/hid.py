
from __future__ import print_function, absolute_import

from .ctap import CtapDevice
from .pyu2f import hidtransport

from enum import IntEnum, unique
import struct


@unique
class CTAPHID(IntEnum):
    PING = 0x01
    MSG = 0x03
    LOCK = 0x04
    INIT = 0x06
    WINK = 0x08
    CBOR = 0x10
    CANCEL = 0x11

    ERROR = 0x3f
    KEEPALIVE = 0x3b

    VENDOR_FIRST = 0x40


@unique
class CAPABILITY(IntEnum):
    WINK = 0x01
    LOCK = 0x02  # Not used
    CBOR = 0x04
    NMSG = 0x08

    def supported(self, flags):
        return bool(flags & self)


TYPE_INIT = 0x80


class CtapHidDevice(CtapDevice):
    """
    CtapDevice implementation using the HID transport.
    """

    def __init__(self, dev):
        self._dev = dev

    @property
    def version(self):
        return self._dev.u2fhid_version

    @property
    def device_version(self):
        return self._dev.device_version

    @property
    def capabilities(self):
        return self._dev.capabilities

    def call(self, cmd, data=b''):
        return bytes(self._dev.InternalExchange(TYPE_INIT | cmd, data))

    def wink(self):
        self.call(CTAPHID.WINK)

    def ping(self, msg=b'Hello U2F'):
        resp = self.call(CTAPHID.PING, msg)
        if resp != msg:
            raise hidtransport.errors.HidError('Incorrect PING readback')
        return resp

    def lock(self, lock_time=10):
        self.call(CTAPHID.LOCK, struct.pack('>B', lock_time))

    def cancel(self):
        self.call(CTAPHID.CANCEL)

    @classmethod
    def list_devices(cls, selector=hidtransport.HidUsageSelector):
        for dev in hidtransport.DiscoverLocalHIDU2FDevices(selector):
            yield cls(dev)
