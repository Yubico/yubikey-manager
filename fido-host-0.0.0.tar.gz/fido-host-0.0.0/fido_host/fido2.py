# Copyright (c) 2018 Yubico AB
# All rights reserved.
#
#   Redistribution and use in source and binary forms, with or
#   without modification, are permitted provided that the following
#   conditions are met:
#
#    1. Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#    2. Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other materials provided
#       with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from __future__ import absolute_import

from . import cbor
from .hid import CTAPHID
from .rpid import verify_rp_id
from .utils import ClientData, sha256
from .constants import CAPABILITY

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hmac, hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from binascii import b2a_hex, a2b_hex
from enum import IntEnum, unique
import struct
import six


class CborError(Exception):

    def __init__(self, code):
        self.code = code

    def __str__(self):
        return 'CBOR command error: 0x{:02X}'.format(self.code)


def args(*args):
    """
    Constructs a dict from a list of arguments for sending a CBOR command.
    """
    if args:
        return dict((i, v) for i, v in enumerate(args, 1) if v is not None)
    return None


class Info(object):
    @unique
    class KEYS(IntEnum):
        VERSIONS = 1
        EXTENSIONS = 2
        AAGUID = 3
        OPTIONS = 4
        MAX_MSG_SIZE = 5
        PIN_PROTOCOLS = 6

    def __init__(self, data):
        self._data = data

    @property
    def versions(self):
        return self._data[Info.KEYS.VERSIONS]

    @property
    def extensions(self):
        return self._data.get(Info.KEYS.EXTENSIONS, [])

    @property
    def aaguid(self):
        return self._data[Info.KEYS.AAGUID]

    @property
    def options(self):
        return self._data.get(Info.KEYS.OPTIONS, {})

    @property
    def max_msg_size(self):
        return self._data.get(Info.KEYS.MAX_MSG_SIZE)

    @property
    def pin_protocols(self):
        return self._data.get(Info.KEYS.PIN_PROTOCOLS, [])


class AttestationObject(object):
    @unique
    class KEYS(IntEnum):
        FMT = 1
        AUTH_DATA = 2
        ATT_STMT = 3

    def __init__(self, data):
        self._data = data

    @property
    def bytes(self):
        return cbor.dumps(self._data)

    @property
    def fmt(self):
        return self._data[AttestationObject.KEYS.FMT]

    @property
    def auth_data(self):
        return AuthenticatorData(self._data[AttestationObject.KEYS.AUTH_DATA])

    @property
    def att_stmt(self):
        return self._data[AttestationObject.KEYS.ATT_STMT]


class AuthenticatorData(object):

    def __init__(self, data):
        self.bytes = data
        self.rp_id_hash = data[0:32]
        self.flags, self.counter = struct.unpack('>BI', data[32:32+5])
        self.aaguid = data[32+5:32+5+16]
        cred_len = struct.unpack('>H', data[32+5+16:32+5+16+2])[0]
        cred_offs = 32+5+16+2
        self.credential_id = data[cred_offs:cred_offs+cred_len]
        self.public_key, extensions = cbor.loads(data[cred_offs+cred_len:])
        self.extensions = cbor.loads(extensions)[0] if extensions else None


class CTAP2(object):
    @unique
    class CMD(IntEnum):
        MAKE_CREDENTIAL = 0x01
        GET_ASSERTION = 0x02
        GET_INFO = 0x04
        CLIENT_PIN = 0x06
        RESET = 0x07
        GET_NEXT_ASSERTION = 0x08

    def __init__(self, device):
        if not device.capabilities & CAPABILITY.CBOR:
            raise ValueError('Device does not support CTAP2.')
        self.device = device

    def send_cbor(self, cmd, data=None):
        """
        Sends a CBOR message to the device, and waits for a response.
        """
        request = struct.pack('>B', cmd)
        if data is not None:
            request += cbor.dumps(data)
        response = self.device.call(CTAPHID.CBOR, request)
        status = six.indexbytes(response, 0)
        if status != 0x00:
            raise CborError(status)
        if len(response) == 1:
            return None
        data, rest = cbor.loads(response[1:])
        if rest != b'':
            raise ValueError('Invalid response')
        return data

    def make_credential(self, client_data_hash, rp, user, key_params,
                        exclude_list=None, extensions=None, options=None,
                        pin_auth=None, pin_protocol=None):
        return self.send_cbor(CTAP2.CMD.MAKE_CREDENTIAL, args(
            client_data_hash,
            rp,
            user,
            key_params,
            exclude_list,
            extensions,
            options,
            pin_auth,
            pin_protocol
        ))

    def get_assertion(self, rp_id, client_data_hash, allow_list=None,
                      extensions=None, options=None, pin_auth=None,
                      pin_protocol=None):
        return self.send_cbor(CTAP2.CMD.GET_ASSERTION, args(
            rp_id,
            client_data_hash,
            allow_list,
            extensions,
            options,
            pin_auth,
            pin_protocol
        ))

    def get_info(self):
        return Info(self.send_cbor(CTAP2.CMD.GET_INFO))

    def client_pin(self, pin_protocol, sub_cmd, key_agreement=None,
                   pin_auth=None, new_pin_enc=None, pin_hash_enc=None):
        return self.send_cbor(CTAP2.CMD.CLIENT_PIN, args(
            pin_protocol,
            sub_cmd,
            key_agreement,
            pin_auth,
            new_pin_enc,
            pin_hash_enc
        ))

    def reset(self):
        self.send_cbor(CTAP2.CMD.RESET)

    def get_next_assertion(self):
        return self.send_cbor(CTAP2.CMD.GET_NEXT_ASSERTION)


def _pad_pin(pin):
    if not isinstance(pin, six.string_types):
        raise ValueError('PIN of wrong type, expecting %s' % six.string_types)
    if len(pin) < 4:
        raise ValueError('PIN must be >= 4 characters')
    pin = pin.encode('utf8').ljust(64, b'\0')
    pin += b'\0' * (-(len(pin) - 16) % 16)
    if len(pin) > 255:
        raise ValueError('PIN must be <= 255 bytes')
    return pin


class PinProtocolV1(object):
    VERSION = 1
    IV = b'\x00' * 16

    @unique
    class CMD(IntEnum):
        GET_RETRIES = 0x01
        GET_KEY_AGREEMENT = 0x02
        SET_PIN = 0x03
        CHANGE_PIN = 0x04
        GET_PIN_TOKEN = 0x05

    @unique
    class RESULT(IntEnum):
        KEY_AGREEMENT = 0x01
        PIN_TOKEN = 0x02
        RETRIES = 0x03

    def __init__(self, ctap):
        self.ctap = ctap

    def _init_shared_secret(self):
        be = default_backend()
        sk = ec.generate_private_key(ec.SECP256R1(), be)
        pk = sk.public_key().public_numbers()
        key_agreement = {
            1: 2,
            3: -15,
            -1: 1,
            -2: a2b_hex('%064x' % pk.x),
            -3: a2b_hex('%064x' % pk.y)
        }

        resp = self.ctap.client_pin(PinProtocolV1.VERSION,
                                    PinProtocolV1.CMD.GET_KEY_AGREEMENT)
        pk = resp[PinProtocolV1.RESULT.KEY_AGREEMENT]
        x = int(b2a_hex(pk[-2]), 16)
        y = int(b2a_hex(pk[-3]), 16)
        pk = ec.EllipticCurvePublicNumbers(x, y, ec.SECP256R1()).public_key(be)
        shared_secret = sha256(sk.exchange(ec.ECDH(), pk))
        return key_agreement, shared_secret

    def get_pin_token(self, pin):
        key_agreement, shared_secret = self._init_shared_secret()

        be = default_backend()
        cipher = Cipher(algorithms.AES(shared_secret),
                        modes.CBC(PinProtocolV1.IV), be)
        pin_hash = sha256(pin.encode())[:16]
        enc = cipher.encryptor()
        pin_hash_enc = enc.update(pin_hash) + enc.finalize()

        resp = self.ctap.client_pin(PinProtocolV1.VERSION,
                                    PinProtocolV1.CMD.GET_PIN_TOKEN,
                                    key_agreement=key_agreement,
                                    pin_hash_enc=pin_hash_enc)
        dec = cipher.decryptor()
        return dec.update(resp[PinProtocolV1.RESULT.PIN_TOKEN]) + dec.finalize()

    def get_pin_retries(self):
        resp = self.ctap.client_pin(PinProtocolV1.VERSION,
                                    PinProtocolV1.CMD.GET_RETRIES)
        return resp[PinProtocolV1.RESULT.RETRIES]

    def set_pin(self, pin):
        pin = _pad_pin(pin)
        key_agreement, shared_secret = self._init_shared_secret()

        be = default_backend()
        cipher = Cipher(algorithms.AES(shared_secret),
                        modes.CBC(PinProtocolV1.IV), be)
        enc = cipher.encryptor()
        pin_enc = enc.update(pin) + enc.finalize()
        h = hmac.HMAC(shared_secret, hashes.SHA256(), be)
        h.update(pin_enc)
        pin_auth = h.finalize()[:16]
        self.ctap.client_pin(PinProtocolV1.VERSION, PinProtocolV1.CMD.SET_PIN,
                             key_agreement=key_agreement,
                             new_pin_enc=pin_enc,
                             pin_auth=pin_auth)

    def change_pin(self, old_pin, new_pin):
        new_pin = _pad_pin(new_pin)
        key_agreement, shared_secret = self._init_shared_secret()

        be = default_backend()
        cipher = Cipher(algorithms.AES(shared_secret),
                        modes.CBC(PinProtocolV1.IV), be)
        pin_hash = sha256(old_pin.encode())[:16]
        enc = cipher.encryptor()
        pin_hash_enc = enc.update(pin_hash) + enc.finalize()
        enc = cipher.encryptor()
        new_pin_enc = enc.update(new_pin) + enc.finalize()
        h = hmac.HMAC(shared_secret, hashes.SHA256(), be)
        h.update(new_pin_enc)
        h.update(pin_hash_enc)
        pin_auth = h.finalize()[:16]
        self.ctap.client_pin(PinProtocolV1.VERSION,
                             PinProtocolV1.CMD.CHANGE_PIN,
                             key_agreement=key_agreement,
                             pin_hash_enc=pin_hash_enc,
                             new_pin_enc=new_pin_enc,
                             pin_auth=pin_auth)


@unique
class CRED_ALGO(IntEnum):
    ES256 = -7
    RS256 = -257


class Fido2Client(object):
    def __init__(self, device, origin, verify=verify_rp_id):
        self.ctap = CTAP2(device)
        self.pin_protocol = PinProtocolV1(self.ctap)
        self.origin = origin
        self._verify = verify_rp_id

    def _verify_rp_id(self, rp_id):
        try:
            if self._verify(rp_id, self.origin):
                return
        except Exception:
            pass  # Fall through to ClientError
        raise ValueError('RP ID')  # TODO

    def make_credential(self, rp, user, challenge, algos=[CRED_ALGO.ES256],
                        exclude_list=None, extensions=None, rk=False, uv=False,
                        pin=None):
        self._verify_rp_id(rp['id'])

        client_data = ClientData.from_dict({
            'type': 'webauthn.create',
            'clientExtensions': {},
            'challenge': challenge,
            'origin': self.origin
        })

        key_params = [{'type': 'public-key', 'alg': alg} for alg in algos]

        info = self.ctap.get_info()
        pin_auth = None
        pin_protocol = None
        if pin:
            pin_protocol = self.pin_protocol.VERSION
            if pin_protocol not in info.pin_protocols:
                raise ValueError('Device does not support PIN protocol 1!')
            pin_token = self.pin_protocol.get_pin_token(pin)
            h = hmac.HMAC(pin_token, hashes.SHA256(), default_backend())
            h.update(client_data.hash)
            pin_auth = h.finalize()[:16]
        elif info.options.get('clientPin'):
            raise ValueError('PIN required!')

        if not (rk or uv):
            options = None
        else:
            options = {}
            if rk:
                options['rk'] = True
            if uv:
                options['uv'] = True

        response = self.ctap.make_credential(client_data.hash, rp, user,
                                             key_params, exclude_list,
                                             extensions, options, pin_auth,
                                             pin_protocol)
        return AttestationObject(response), client_data
